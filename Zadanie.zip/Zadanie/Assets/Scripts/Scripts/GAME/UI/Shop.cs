﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UI;
using UnityEngine.UI;

namespace Game.UI
{
    /// <summary>
    /// ViewController of the Shop. Should contain view and basic mechanics of the shop.
    /// </summary>
    public class Shop : GridListViewController<Item>
    {
        public override string headerText => "Buy Items";

        /// <summary>
        /// All items from config.
        /// </summary>
        public override List<Item> data => Manager.Instance.config.items;


        /// <summary>
        /// When Cell is clicked.
        /// </summary>
        /// <param name="item"></param>
        public override void OnCellClick(Item item)
        {
            Debug.Log("Taks for you");
            ///TODO:1. Take Money from player.
            ///TODO:2. Give player the item.
        }
    }
}